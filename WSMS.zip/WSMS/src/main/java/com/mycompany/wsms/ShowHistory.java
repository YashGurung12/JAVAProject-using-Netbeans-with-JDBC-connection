/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.wsms;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author yashg
 */
public class ShowHistory extends javax.swing.JFrame {

    /**
     * Creates new form ShowHistory
     */
    
    private final Connection conn;
    private PreparedStatement stmt;
    private ResultSet rs;
    private final JPanel mainPanel;
    private final JTable table;
    public ShowHistory() {
        
         super("ShowHistory");
         
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         setSize(550, 550);
         
           String imagePath = "C:\\Users\\yashg\\OneDrive\\Desktop\\JAVA\\waterlogo.jpg";

        // Create an ImageIcon from the .jpeg image file
        ImageIcon icon = new ImageIcon(imagePath);

        // Set the image as the title icon
        setIconImage(icon.getImage());

        // Connect to database
        conn = databaseConnection.connection();
        
        mainPanel = new JPanel();
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setLayout(null);
        setContentPane(mainPanel);
       
JButton backButton= new JButton("BACK");
backButton.setBounds(5, 470, 80, 30);
backButton.setBackground(Color.red);
mainPanel.add(backButton);

        // Create and set title label
        JLabel titleLabel = new JLabel("Billing History");
        titleLabel.setFont(new Font("Helvetica Neue", Font.BOLD, 18));
        titleLabel.setBounds(220, 20, 200, 30);
        mainPanel.add(titleLabel);

        // Create and set table
        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 60, 500, 400);
        mainPanel.add(scrollPane);

        // Create and set back button
       
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
               Home object = new Home();
               object.setVisible(true);
                dispose();
            }
        });

        // Show records in table
        showRecords();

        // Display frame
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    
   public void updateTotalBill(int newBillValue) {
    try {
        if (conn != null) {
            String sql = "UPDATE History SET TotalBill = TotalBill + ? WHERE CustomerName=?"; // Replace <condition> with the appropriate condition to identify the row you want to update
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, newBillValue);
            stmt.executeUpdate();
            showRecords(); // Refresh the table after updating the value
        } else {
            JOptionPane.showMessageDialog(null, "Not connected to database");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, e.getMessage());
    }
}
    
    
    public void showRecords(){
        try {
            if (conn != null) {
                String sql = "SELECT * FROM history";
                stmt = conn.prepareStatement(sql);
                rs = stmt.executeQuery();
                table.setModel(buildTableModel(rs));
            } else {
                JOptionPane.showMessageDialog(null, "Not connected to database");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    public static DefaultTableModel buildTableModel(ResultSet rs) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();

        // Get column names
        int columnCount = metaData.getColumnCount();
        Vector<String> columnNames = new Vector<String>();
        for (int column = 1; column <= columnCount; column++) {
            columnNames.add(metaData.getColumnName(column));
        }

        // Get row data
        Vector<Vector<Object>> data = new Vector<Vector<Object>>();
        while (rs.next()) {
            Vector<Object> row = new Vector<Object>();
            for (int column = 1; column <= columnCount; column++) {
                row.add(rs.getObject(column));
            }
            data.add(row);
        }

        return new DefaultTableModel(data, columnNames);
    }  
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ShowHistory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ShowHistory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ShowHistory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ShowHistory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ShowHistory().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
