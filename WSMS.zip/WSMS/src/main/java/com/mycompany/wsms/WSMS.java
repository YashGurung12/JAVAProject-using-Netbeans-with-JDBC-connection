/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.wsms;

/**
 *
 * @author yashg
 */
public class WSMS {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
