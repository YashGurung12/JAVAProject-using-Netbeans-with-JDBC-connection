/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.wsms;

import static com.mycompany.wsms.ShowCustomers.buildTableModel;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 *
 * @author yashg
 */

public class ShowCBills extends javax.swing.JFrame {

    /**
     * Creates new form ShowCBills
     */
     private JButton removeButton;
     
        private final Connection conn;
    private PreparedStatement stmt;
    private ResultSet rs;
    private final JPanel mainPanel;
    private final JTable table;
        public void close()
{
    WindowEvent cw=new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
    Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(cw);
}
      
    public ShowCBills() {
        super("ShowCBills");
        initComponents();
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(550, 550);
String imagePath = "C:\\Users\\yashg\\OneDrive\\Desktop\\JAVA\\waterlogo.jpg";

        // Create an ImageIcon from the .jpeg image file
        ImageIcon icon = new ImageIcon(imagePath);

        // Set the image as the title icon
        setIconImage(icon.getImage());
        // Connect to database
        conn = databaseConnection.connection();
        
        mainPanel = new JPanel();
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setLayout(null);
        setContentPane(mainPanel); 
        removeButton = new JButton("Remove");
removeButton.setBounds(220, 470, 100, 30);
mainPanel.add(removeButton);

JButton backButton= new JButton("BACK");
backButton.setBounds(5, 470, 80, 30);
backButton.setBackground(Color.red);
mainPanel.add(backButton);
 backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Home object = new Home();
                object.setVisible(true);
                dispose();
            }
        });

removeButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Get the selected row index
        int selectedRow = table.getSelectedRow();

        // Check if a row is selected
        if (selectedRow != -1) {
            // Get the ID value from the selected row
            int billId = (int) table.getValueAt(selectedRow, 0);

            // Call a method to remove the selected bill
            removeBill(billId);
        } else {
            JOptionPane.showMessageDialog(null, "No row selected");
        }
    }
});

        // Create and set title label
        JLabel titleLabel = new JLabel("BILLS");
        titleLabel.setFont(new Font("Helvetica Neue", Font.BOLD, 18));
        titleLabel.setBounds(230, 20, 100, 30);
        mainPanel.add(titleLabel);

        // Create and set table
        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 60, 500, 400);
        mainPanel.add(scrollPane);

        // Create and set back button
        backButton = new JButton("Back");
        backButton.setBounds(200, 250, 100, 30);
        mainPanel.add(backButton);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
               Home object = new Home();
               object.setVisible(true);
                dispose();
            }
        });

        // Show records in table
        showRecords();

        // Display frame
        setLocationRelativeTo(null);
        setVisible(true);
    }
    public void removeBill(int billId) {
      try {
        if (conn != null) {
            // Prepare the SQL statement to delete the bill with the given ID
            String sql1 = "DELETE FROM bills WHERE Slno=?";
            PreparedStatement stmt1 = conn.prepareStatement(sql1);
            stmt1.setInt(1, billId);

            // Execute the delete statement for bills
            int rowsAffected1 = stmt1.executeUpdate();

            // Check if the delete operation for bills was successful
            if (rowsAffected1 > 0) {
                // Prepare the SQL statement to delete the customer with the given ID
                String sql2 = "DELETE FROM customers WHERE Slno=?";
                PreparedStatement stmt2 = conn.prepareStatement(sql2);
                stmt2.setInt(1, billId);

                // Execute the delete statement for customers
                int rowsAffected2 = stmt2.executeUpdate();

                // Check if the delete operation for customers was successful
                if (rowsAffected2 > 0) {
                    // Show a success message
                    JOptionPane.showMessageDialog(null, "Customer removed successfully");

                    // Refresh the table
                    showRecords();
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to remove customer");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Failed to remove bill");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Not connected to database");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, e.getMessage());
    }
}









                // Refresh the table
                
          
    public void showRecords(){
        try {
            if (conn != null) {
                String sql = "SELECT * FROM bills";
                stmt = conn.prepareStatement(sql);
                rs = stmt.executeQuery();
                table.setModel(buildTableModel(rs));
            } else {
                JOptionPane.showMessageDialog(null, "Not connected to database");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
private void backButtonActionPerformed(java.awt.event.ActionEvent evt) { 
    
        // TODO add your handling code here:
        close();
    Home h=new Home();
    h.setVisible(true);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ShowCBills.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ShowCBills.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ShowCBills.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ShowCBills.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ShowCBills().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
